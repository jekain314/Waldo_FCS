PLACE THE CANON SDK DLLs HERE!

DPPDLL.dll
DPPLibCom.dll
DPPRSC.dll
EDSDK.dll
EdsImage.dll
Mlib.dll
Ucs32P.dll